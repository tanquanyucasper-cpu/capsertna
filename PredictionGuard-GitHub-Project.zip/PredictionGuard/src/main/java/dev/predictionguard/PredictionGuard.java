package dev.predictionguard;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PredictionGuard extends JavaPlugin implements Listener {
    private final Map<UUID, PlayerState> states = new ConcurrentHashMap<>();

    @Override public void onEnable() {
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        if (getCommand("predictionguard") != null) {
            getCommand("predictionguard").setExecutor((sender, command, label, args) -> {
                if (!sender.hasPermission("predictionguard.admin")) {
                    sender.sendMessage(ChatColor.RED + "You do not have permission.");
                    return true;
                }
                if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
                    reloadConfig();
                    sender.sendMessage(ChatColor.GREEN + "PredictionGuard config reloaded.");
                } else if (args.length == 1 && args[0].equalsIgnoreCase("status")) {
                    sender.sendMessage(ChatColor.GOLD + "PredictionGuard active; tracking " + states.size() + " players.");
                } else {
                    sender.sendMessage(ChatColor.YELLOW + "/pg reload | /pg status");
                }
                return true;
            });
        }
        for (Player p : Bukkit.getOnlinePlayers()) states.put(p.getUniqueId(), new PlayerState(p.getLocation()));
        getLogger().info("PredictionGuard enabled. Tune config.yml on a staging server first.");
    }

    @Override public void onDisable() { states.clear(); }

    @EventHandler public void onJoin(PlayerJoinEvent e) {
        PlayerState s = new PlayerState(e.getPlayer().getLocation());
        s.graceTicks = getConfig().getInt("checks.join-grace-ticks", 30);
        states.put(e.getPlayer().getUniqueId(), s);
    }

    @EventHandler public void onQuit(PlayerQuitEvent e) { states.remove(e.getPlayer().getUniqueId()); }

    @EventHandler public void onWorldChange(PlayerChangedWorldEvent e) { reset(e.getPlayer(), 12); }

    @EventHandler public void onRespawn(PlayerRespawnEvent e) {
        Bukkit.getScheduler().runTask(this, () -> reset(e.getPlayer(), 15));
    }

    @EventHandler public void onTeleport(PlayerTeleportEvent e) {
        if (e.getTo() != null) {
            PlayerState s = states.computeIfAbsent(e.getPlayer().getUniqueId(), k -> new PlayerState(e.getTo()));
            s.lastSafe = e.getTo().clone();
            s.expectedYVelocity = 0;
            s.graceTicks = getConfig().getInt("checks.teleport-grace-ticks", 12);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p) {
            PlayerState s = states.get(p.getUniqueId());
            if (s != null) s.graceTicks = Math.max(s.graceTicks, getConfig().getInt("checks.knockback-grace-ticks", 8));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamageByEntity(EntityDamageByEntityEvent e) {
        if (e.getEntity() instanceof Player p) {
            PlayerState s = states.get(p.getUniqueId());
            if (s != null) {
                s.graceTicks = Math.max(s.graceTicks, getConfig().getInt("checks.knockback-grace-ticks", 8));
                Vector kb = p.getVelocity();
                s.expectedYVelocity = Math.max(s.expectedYVelocity, kb.getY());
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!getConfig().getBoolean("checks.enabled", true) || e.getTo() == null) return;
        Player p = e.getPlayer();
        Location from = e.getFrom(), to = e.getTo();
        if (from.getWorld() != to.getWorld()) { reset(p, 12); return; }
        if (samePosition(from, to)) return;

        PlayerState s = states.computeIfAbsent(p.getUniqueId(), k -> new PlayerState(from));
        if (s.graceTicks > 0) {
            s.graceTicks--;
            s.lastSafe = to.clone();
            s.expectedYVelocity = p.getVelocity().getY();
            return;
        }

        if (isExempt(p, from, to)) {
            s.lastSafe = to.clone();
            s.expectedYVelocity = p.getVelocity().getY();
            s.suspicion = Math.max(0, s.suspicion - 0.2);
            return;
        }

        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        double dy = to.getY() - from.getY();
        double horizontal = Math.hypot(dx, dz);

        // Sanity checks catch impossible event-level coordinates/deltas. They are not a raw packet decoder.
        double maxCoord = getConfig().getDouble("checks.max-world-coordinate", 30_000_000.0);
        if (!finite(to.getX()) || !finite(to.getY()) || !finite(to.getZ())
                || Math.abs(to.getX()) > maxCoord || Math.abs(to.getZ()) > maxCoord
                || horizontal > getConfig().getDouble("checks.max-horizontal-distance-per-tick", 2.2)
                || Math.abs(dy) > getConfig().getDouble("checks.max-vertical-distance-per-tick", 3.5)) {
            flag(p, s, "movement sanity", horizontal, dy, 2.0);
            // Avoid cancelling ordinary plugin teleports; only cancel obviously out-of-envelope moves.
            e.setCancelled(true);
            return;
        }

        boolean grounded = p.isOnGround() || isNearGround(to);
        boolean liquidOrClimbable = isSpecialMovementBlock(p, from, to);
        double verticalTolerance = getConfig().getDouble("checks.vertical-tolerance", 0.085);
        if (p.hasPotionEffect(PotionEffectType.JUMP_BOOST)) {
            verticalTolerance += (p.getPotionEffect(PotionEffectType.JUMP_BOOST).getAmplifier() + 1)
                    * getConfig().getDouble("checks.jump-boost-tolerance-per-level", 0.12);
        }
        if (p.hasPotionEffect(PotionEffectType.LEVITATION)
                || p.hasPotionEffect(PotionEffectType.SLOW_FALLING) || liquidOrClimbable) {
            verticalTolerance += 0.5;
        }

        // A simple discrete vertical-motion envelope: gravity then drag, with ground/jump allowances.
        // This is a heuristic model, not a full vanilla client physics clone.
        double actualVelocity = dy;
        double predicted = s.expectedYVelocity;
        if (grounded && dy <= 0.08) predicted = Math.max(predicted, 0.0);
        else predicted = (predicted - 0.08) * 0.98;
        boolean suspiciousVertical = !grounded && !p.isFlying() && !p.isGliding()
                && !p.isInsideVehicle() && !liquidOrClimbable
                && actualVelocity > predicted + verticalTolerance
                && dy > 0.12;

        double baseHorizontal = getWalkSpeedEstimate(p);
        double horizontalTolerance = getConfig().getDouble("checks.horizontal-tolerance", 0.12);
        if (p.hasPermission(getConfig().getString("checks.speed-permission", "predictionguard.speedexempt"))) {
            horizontalTolerance += getConfig().getDouble("checks.speed-permission-horizontal-tolerance", 0.35);
        }
        if (p.isSprinting()) baseHorizontal *= 1.3;
        if (p.isSneaking()) baseHorizontal *= 0.3;
        if (p.isSwimming()) baseHorizontal *= 1.8;
        if (p.isGliding() || p.isFlying() || p.isInsideVehicle() || liquidOrClimbable) baseHorizontal = Double.MAX_VALUE;
        boolean suspiciousHorizontal = horizontal > baseHorizontal + horizontalTolerance;

        if (suspiciousVertical) flag(p, s, "vertical prediction", horizontal, dy, 1.0);
        else if (suspiciousHorizontal) flag(p, s, "horizontal envelope", horizontal, dy, 0.65);
        else s.suspicion = Math.max(0, s.suspicion - getConfig().getDouble("checks.suspicion-decay-per-clean-move", 0.35));

        // Update the predictor using observed motion, but clamp to limit contamination by outliers.
        s.expectedYVelocity = Math.max(-3.5, Math.min(3.5, p.getVelocity().getY()));
        if (grounded) {
            s.lastSafe = to.clone();
            if (dy <= 0.08) s.expectedYVelocity = 0;
        }
        if (getConfig().getBoolean("checks.setback-enabled", false)
                && s.suspicion >= getConfig().getDouble("checks.setback-threshold", 10.0)
                && s.lastSafe != null && !suspiciousVertical && !suspiciousHorizontal) {
            p.teleport(s.lastSafe);
            s.expectedYVelocity = 0;
            s.graceTicks = 4;
        }
    }

    private double getWalkSpeedEstimate(Player p) {
        // Bukkit walk speed is a client movement setting; vanilla default 0.2 corresponds to ~0.28 blocks/tick.
        double walk = Math.max(0.0, p.getWalkSpeed()) / 0.2 * 0.28;
        try {
            var attr = p.getAttribute(Attribute.MOVEMENT_SPEED);
            if (attr != null) walk = Math.max(walk, attr.getValue() * 4.3);
        } catch (NoSuchMethodError ignored) { }
        if (p.hasPotionEffect(PotionEffectType.SPEED)) {
            int level = p.getPotionEffect(PotionEffectType.SPEED).getAmplifier() + 1;
            walk *= (1.0 + 0.2 * level);
        }
        return walk;
    }

    private boolean isExempt(Player p, Location from, Location to) {
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR
                || p.isFlying() || p.isGliding() || p.isInsideVehicle() || p.isDead()) return true;
        if (p.getAllowFlight() && p.isFlying()) return true;
        if (p.hasPotionEffect(PotionEffectType.LEVITATION)) return true;
        return isSpecialMovementBlock(p, from, to);
    }

    private boolean isSpecialMovementBlock(Player p, Location from, Location to) {
        if (p.isSwimming() || p.isInWater() || p.isInLava()) return true;
        return specialBlock(from) || specialBlock(to);
    }

    private boolean specialBlock(Location l) {
        if (l.getWorld() == null) return false;
        for (int y = l.getBlockY(); y <= l.getBlockY() + 1; y++) {
            Material m = l.getWorld().getBlockAt(l.getBlockX(), y, l.getBlockZ()).getType();
            String n = m.name();
            if (m == Material.LADDER || m == Material.VINE || m == Material.SCAFFOLDING
                    || m == Material.COBWEB || m == Material.SLIME_BLOCK || m == Material.HONEY_BLOCK
                    || n.contains("WATER") || n.contains("BUBBLE_COLUMN")) return true;
        }
        return false;
    }

    private boolean isNearGround(Location l) {
        if (l.getWorld() == null) return false;
        return l.clone().subtract(0, 0.08, 0).getBlock().getType().isSolid();
    }

    private void flag(Player p, PlayerState s, String reason, double horizontal, double dy, double weight) {
        s.suspicion = Math.min(getConfig().getDouble("checks.max-suspicion", 20.0), s.suspicion + weight);
        int threshold = getConfig().getInt("checks.alert-threshold", 6);
        if (s.suspicion >= threshold && !s.alertedThisBurst) {
            String msg = ChatColor.RED + "[PredictionGuard] " + ChatColor.YELLOW + p.getName()
                    + ChatColor.GRAY + " suspected: " + reason + " (buffer=" + String.format("%.1f", s.suspicion)
                    + ", h=" + String.format("%.3f", horizontal) + ", dy=" + String.format("%.3f", dy) + ")";
            if (getConfig().getBoolean("checks.alerts-to-console", true)) getLogger().warning(ChatColor.stripColor(msg));
            if (getConfig().getBoolean("checks.alerts-to-permission", true)) {
                for (Player staff : Bukkit.getOnlinePlayers()) {
                    if (staff.hasPermission("predictionguard.alerts")) staff.sendMessage(msg);
                }
            }
            s.alertedThisBurst = true;
        }
        if (s.suspicion < threshold * 0.5) s.alertedThisBurst = false;
    }

    private void reset(Player p, int grace) {
        PlayerState s = states.computeIfAbsent(p.getUniqueId(), k -> new PlayerState(p.getLocation()));
        s.lastSafe = p.getLocation().clone();
        s.expectedYVelocity = 0;
        s.graceTicks = grace;
        s.suspicion = 0;
        s.alertedThisBurst = false;
    }

    private boolean samePosition(Location a, Location b) {
        return a.getX() == b.getX() && a.getY() == b.getY() && a.getZ() == b.getZ();
    }
    private boolean finite(double d) { return Double.isFinite(d); }

    private static final class PlayerState {
        Location lastSafe;
        double expectedYVelocity;
        double suspicion;
        int graceTicks;
        boolean alertedThisBurst;
        PlayerState(Location initial) { lastSafe = initial.clone(); }
    }
}
