# PredictionGuard

A Maven-built Paper/Spigot movement-check plugin scaffold targeting Minecraft 1.21.11 and Java 21.

## Features
- Lightweight per-player vertical motion prediction with a tolerance envelope.
- Horizontal movement envelope with allowances for sprinting, sneaking, Speed potion, Bukkit walk speed, and a permission-based custom-speed allowance.
- Grace windows after joining, teleporting, respawning, world changes, and damage/knockback.
- Exemptions/allowances for creative/spectator flight, elytra, vehicles, water/lava, climbing blocks, levitation, slow falling, jump boost, slime/honey and similar movement contexts.
- Event-level sanity checks for non-finite/extreme coordinates and implausible per-tick deltas.
- Staff alerts and suspicion buffering. Automatic setback is disabled by default.

## Build into a JAR
Requires JDK 21 and Maven 3.9+.

Linux/macOS:
```bash
mvn clean package
```
Windows PowerShell:
```powershell
mvn clean package
```

The built plugin will be at:
`target/PredictionGuard-0.1.0-SNAPSHOT.jar`

Copy it into your server's `plugins/` folder and restart the server. Review `plugins/PredictionGuard/config.yml`.

## Commands
- `/pg status`
- `/pg reload`

Permission nodes:
- `predictionguard.admin` (default: op)
- `predictionguard.alerts` (default: op)
- `predictionguard.speedexempt` (assign to players or groups with custom/modded speed mechanics)

## Important limitations
This is a conservative starter implementation, **not production-ready anti-cheat**. Bukkit/Paper movement events do not expose every raw client packet, and the server may reject or normalize malformed packets before a plugin sees them. The current sanity checks therefore inspect movement events, not raw protocol packets. For genuine packet-level validation, add and test a maintained packet library integration (for example PacketEvents or ProtocolLib) compatible with your exact server build.

The prediction is intentionally a heuristic envelope, not a bit-for-bit simulation of the vanilla client. It can flag legitimate movement and miss sophisticated cheats. Custom movement plugins, launch pads, pistons, slime, knockback, riptide, tridents, powder snow, vehicles, unusual attributes, and server lag can require extra exemptions or wider tolerances. Test with representative players and plugins before enabling setback. Do not use automatic punishment until you have reviewed false positives.

## GitHub repository setup
1. Create an empty GitHub repository named `PredictionGuard`.
2. Extract this ZIP and push the contents:
```bash
git init
git add .
git commit -m "Initial PredictionGuard scaffold"
git branch -M main
git remote add origin https://github.com/YOUR-NAME/PredictionGuard.git
git push -u origin main
```
3. To build a JAR locally or in GitHub Actions, run `mvn clean package` using JDK 21. A workflow can be added once you share the repository URL and preferred branch.

## Next development steps
- Replace heuristic movement checks with per-tick state tracking and scenario-based vanilla physics tests.
- Add packet-library checks for invalid packet ordering, impossible rotations/coordinates, and malformed movement state.
- Add unit/integration tests on a staging Paper server, including latency and custom movement plugins.
